from setuptools import setup

setup(
    name='escape_velocity',
    version=1.1,
    description='This module calculate the escape velocity',
    author='ESLH',
    author_email='efnsan001@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['escape_velocity']
)